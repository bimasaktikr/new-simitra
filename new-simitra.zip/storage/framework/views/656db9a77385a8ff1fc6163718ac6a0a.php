<?php if($paginator->hasPages()): ?>
    <nav class="flex justify-end">
        <ul class="inline-flex items-center -space-x-px">
            
            <?php if($paginator->onFirstPage()): ?>
                <li><span class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 rounded-l-lg dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400">Previous</span></li>
            <?php else: ?>
                <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200">Previous</a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li><span class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400"><?php echo e($element); ?></span></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php
                        $start = max(1, $paginator->currentPage() - 2);
                        $end = min($start + 2, $paginator->lastPage());
                        $start = max(1, $end - 4);
                    ?>

                    <?php if($start > 1): ?>
                        <li><a href="<?php echo e($paginator->url(1)); ?>" class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200">1</a></li>
                        <li><span class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400">...</span></li>
                    <?php endif; ?>

                    <?php for($page = $start; $page <= $end; $page++): ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li><span class="px-3 py-2 text-sm text-white bg-blue-500 border border-gray-300 dark:bg-blue-700 dark:border-gray-700"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($paginator->url($page)); ?>" class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($end < $paginator->lastPage()): ?>
                        <li><span class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400">...</span></li>
                        <li><a href="<?php echo e($paginator->url($paginator->lastPage())); ?>" class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200"><?php echo e($paginator->lastPage()); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200">Next</a></li>
            <?php else: ?>
                <li><span class="px-3 py-2 text-sm text-gray-500 bg-white border border-gray-300 rounded-r-lg dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400">Next</span></li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\lapto\Documents\00. Application Project's\new-simitra\resources\views/components/pagination.blade.php ENDPATH**/ ?>