<?php $__env->startSection('content'); ?>
<div class="container px-4 py-6 mx-auto bg-white dark:bg-gray-900">
    <h1 class="mb-6 text-3xl font-bold text-gray-900 dark:text-gray-100">Penilaian Survei</h1>

    <div class="p-6 mb-6 bg-gray-100 rounded-md shadow-md dark:bg-gray-800">
        <p class="pb-2 text-gray-900 dark:text-gray-100">Nama : <?php echo e($mitra_teladan->mitra->name); ?></p>
        <p class="pb-2 text-gray-900 dark:text-gray-100">Mitra Teladan Team  <?php echo e($mitra_teladan->team->name); ?></p>
        <p class="pb-2 text-gray-900 dark:text-gray-100">Tahun  <?php echo e($mitra_teladan->year); ?> & Triwulan <?php echo e($mitra_teladan->quarter); ?></p>
    </div>

    <form id="penilaianForm" action="<?php echo e(route('penilaian2.update', $nilai_2->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <input type="hidden" name="nilai_2_id" value="<?php echo e($nilai_2->id); ?>">
        
        <div class="p-6 bg-gray-100 rounded-md shadow-md dark:bg-gray-800">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-300">
                <thead class="text-xs text-gray-700 uppercase dark:text-gray-400 bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th scope="col" class="px-6 py-3">Variabel</th>
                        <th scope="col" class="px-6 py-3 text-center">Sangat Buruk</th>
                        <th scope="col" class="px-6 py-3 text-center">Buruk</th>
                        <th scope="col" class="px-6 py-3 text-center">Cukup</th>
                        <th scope="col" class="px-6 py-3 text-center">Baik</th>
                        <th scope="col" class="px-6 py-3 text-center">Sangat Baik</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $penilaian2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                            <td class="px-6 py-4 font-medium text-gray-900 dark:text-gray-100"><?php echo e($var->variabel); ?></td>
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <td class="px-6 py-4 text-center">
                                    <input type="radio" name="aspek<?php echo e($key + 1); ?>" value="<?php echo e($i); ?>" 
                                    <?php echo e(old("aspek" . ($key + 1), $nilai_2->{'aspek' . ($key + 1)} == $i ? 'checked' : '')); ?>

                                    class="text-blue-600 form-radio dark:text-blue-400 required">
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="flex justify-between mt-6">
            <button type="button" onclick="window.history.back()" class="px-6 py-2 text-white bg-gray-600 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 dark:focus:ring-gray-600">
                Back
            </button>

             <!-- Submit Button -->
             <button type="button" onclick="confirmSubmission()" class="px-4 py-2 text-white bg-orange-500 border border-transparent rounded-lg shadow-sm accept-btn hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 dark:bg-orange-600 dark:hover:bg-orange-700">
                Kirim
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmSubmission() {
        Swal.fire({
            title: 'Are you sure?',
            text: 'Do you want to finalize the evaluation?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6', 
            cancelButtonColor: '#d33', 
            confirmButtonText: 'Yes, confirm!',
            cancelButtonText: 'Cancel',
            html: `
                <label>
                    <input type="checkbox" id="isFinalCheckbox"> Mark as Final
                </label>
            `,
            preConfirm: () => {
                const isFinal = document.getElementById('isFinalCheckbox').checked;
                return { is_final: isFinal ? 1 : 0 };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const isFinalInput = document.createElement('input');
                isFinalInput.type = 'hidden';
                isFinalInput.name = 'is_final';
                isFinalInput.value = result.value.is_final;

                const form = document.getElementById('penilaianForm');
                form.appendChild(isFinalInput);
                
                console.log('is_final:', isFinalInput.value); // Add this to debug
                
                form.submit();
            }
        });
    }
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lapto\Documents\00. Application Project's\new-simitra\resources\views/penilaian2/edit.blade.php ENDPATH**/ ?>