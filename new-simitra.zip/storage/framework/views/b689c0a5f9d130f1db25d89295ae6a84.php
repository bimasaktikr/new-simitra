<table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 mb-5">
    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
            <th scope="col" class="px-6 py-3">No</th>
            <th scope="col" class="px-6 py-3">Mitra</th>
            <th scope="col" class="px-6 py-3">Survei</th>
            <th scope="col" class="px-6 py-3">Kode Survei</th>
            <th scope="col" class="px-6 py-3">Target</th>
            <th scope="col" class="px-6 py-3">Pembayaran</th>
            <th scope="col" class="px-6 py-3">Total Pembayaran</th>
            <th scope="col" class="px-6 py-3">Nilai</th>
        </tr>
    </thead>
    <tbody>
        <?php if($transactions->isEmpty()): ?>
            <tr>
                <td colspan="5" class="px-6 py-4 text-center">Transaksi tidak ditemukan.</td>
            </tr>
        <?php else: ?>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td class="px-6 py-4"><?php echo e($transactions->firstItem() + $index); ?></td>
                    <td class="px-6 py-4"><?php echo e($transaction->mitra->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($transaction->survey->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($transaction->survey->code); ?></td>
                    <td class="px-6 py-4"><?php echo e($transaction->target); ?></td>
                    <td class="px-6 py-4"><?php echo e(number_format($transaction->payment, 2)); ?></td>
                    <td class="px-6 py-4"><?php echo e(number_format($transaction->payment*$transaction->target, 2)); ?></td>
                    <td class="px-6 py-4"><?php echo e($transaction->nilai1->rerata ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($transactions->links()); ?>


<?php /**PATH C:\Users\lapto\Documents\00. Application Project's\new-simitra\resources\views/transaction/table.blade.php ENDPATH**/ ?>