<table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 mb-5">
    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
            <th scope="col" class="px-6 py-3">No</th>
            <th scope="col" class="px-6 py-3">Nama Survei</th>
            <th scope="col" class="px-6 py-3">Kode</th>
            <th scope="col" class="px-6 py-3">Tim</th>
            <th scope="col" class="px-6 py-3">Tanggal Mulai</th>
            <th scope="col" class="px-6 py-3">Tanggal Berakhir</th>
            <th scope="col" class="px-6 py-3">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if($surveys->isEmpty()): ?>
            <tr>
                <td colspan="5" class="px-6 py-4 text-center">Survei tidak ditemukan.</td>
            </tr>
        <?php else: ?>
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td class="px-6 py-4"><?php echo e($surveys->firstItem() + $index); ?></td>
                    <td class="px-6 py-4"><?php echo e($survey->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($survey->code); ?></td>
                    <td class="px-6 py-4"><?php echo e($survey->team_name); ?></td>
                    <td class="px-6 py-4"><?php echo e($survey->start_date); ?></td>
                    <td class="px-6 py-4"><?php echo e($survey->end_date); ?></td>
                    <td class="px-6 py-4">
                        <div class="flex space-x-2">
                            <button onclick="window.location='<?php echo e(route('surveidetail', $survey->id)); ?>'" class="px-3 py-1 text-white bg-blue-600 rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-blue-700 dark:hover:bg-blue-800">Lihat</button>
                            <button type="button" onclick="toggleModal('deleteModal', '<?php echo e(route('surveys.destroy', $survey->id)); ?>')" class="flex items-center justify-center w-10 h-10 text-red-600 rounded-full hover:text-red-700 focus:outline-none focus:ring-2 focus:ring-red-500">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($surveys->links()); ?>


<?php /**PATH C:\Users\lapto\Documents\00. Application Project's\new-simitra\resources\views/surveytable.blade.php ENDPATH**/ ?>